hl.monitor({
    output   = "",
    mode     = "preferred",
    position = "auto",
    scale    = "1.33",
})

require("env")
require("look")
require("input")
require("gestures")
require("binds")
require("windowrules")
require("scrolloverview")
require("autostart")